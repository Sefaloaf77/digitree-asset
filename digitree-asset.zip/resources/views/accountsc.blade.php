@extends('Layout.layout')

@section('content')

@endsection
@section('script')

    <!-- ApexCharts js -->
    <script src="{{ asset('assets/js/apexcharts.js') }}"></script>
    <script src="{{ asset('assets/js/apex-analytics.js') }}"></script>

@endsection