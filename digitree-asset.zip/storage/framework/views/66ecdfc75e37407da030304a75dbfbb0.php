<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body class="m-0 font-sans antialiased font-normal bg-white text-start text-base leading-default text-slate-500">
    <div class="mt-0 transition-all duration-200 ease-soft-in-out">

        <div class="flex h-screen">
            <!-- Bagian Gambar -->
            <div class="w-full lg:w-1/2 h-screen">
                <img src="<?php echo e(asset('assets/img/cover-login-2.jpg')); ?>" alt="image cover" class="object-cover h-screen">
            </div>

            <!-- Bagian Form -->
            <div class="w-full lg:w-1/2 flex flex-col justify-center items-center px-8">
                <!-- Logo Probolinggo -->

                <img src="<?php echo e(asset('assets/img/logo-probolinggo.png')); ?>" alt="logo probolinggo" class="h-14 w-18">
                
                <!-- Logo Digitree -->
               
                    <img src="<?php echo e(asset('assets/img/logo-digitree.png')); ?>" style="" alt="logo digitree" class="h-10 w-30">
                
                <!-- Form -->
                <div class="w-full max-w-md bg-white p-8">
                    <?php echo e($slot); ?>

                </div>
            </div>
        </div>
    </div>
</body>
<!-- All javascirpt -->
<?php echo $__env->make('partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</html>
<?php /**PATH D:\KZ\1Docs\Project\digitree-asset\resources\views/layouts/guest.blade.php ENDPATH**/ ?>