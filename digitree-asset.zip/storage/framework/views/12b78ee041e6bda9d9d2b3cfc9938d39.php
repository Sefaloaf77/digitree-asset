<!-- All javascirpt -->
<!-- Alpine js -->
<script src="<?php echo e(asset('assets/js/alpine-collaspe.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/alpine-persist.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/alpine.min.js')); ?>" defer></script>


<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php echo $__env->yieldContent('script'); ?>

<!-- Custom js -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

<?php /**PATH D:\KZ\1Docs\Project\digitree-asset\resources\views/partials/scripts.blade.php ENDPATH**/ ?>