<footer
    class="bg-white border-2 border-lightgray/10 p-5 rounded-lg flex flex-wrap justify-center gap-3 sm:justify-between items-center">
    <p class="font-semibold">
        &copy;
        <script>
            var year = new Date(); document.write(year.getFullYear());
        </script>
        Digitree
    </p>
    <ul class="sm:flex items-center text-dark gap-4 sm:gap-[30px] font-semibold hidden">
        <li><a href="javascirpt:;" class="hover:text-primary transition-all duration-300 cursor-pointer">Pemerintah Kota
                Probolinggo</a></li>
    </ul>
</footer><?php /**PATH D:\KZ\1Docs\Project\digitree-asset\resources\views/partials/footer.blade.php ENDPATH**/ ?>